
########### how to install on firefox############

0. download zip file and unzip or clone repo 

1. open firefox browser

2. click menu. then click "Add-ons"

3. click on gear icon and select "debug Add-ons"

4. click on "Load temprary Add-ons"

5. select one of file that is inside of what you unzip in step 0

6. enjoy

################# run without installing on browser#############

0. download zip file or clone repo

1. unzip

2. double click on index.html
