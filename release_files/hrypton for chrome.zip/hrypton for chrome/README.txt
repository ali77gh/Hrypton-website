################### how to install on chrome#######################

0. download zip file and unzip or clone repo 

1. open your browser

2. type chrome://extensions/

3. make develper mode enable

4. click on "Load unpacked"

5. select folder of what you unzip in step 0 folder

6. enjoy

################# run without installing on browser##################

0. download zip file or clone repo

1. unzip

2. double click on index.html
